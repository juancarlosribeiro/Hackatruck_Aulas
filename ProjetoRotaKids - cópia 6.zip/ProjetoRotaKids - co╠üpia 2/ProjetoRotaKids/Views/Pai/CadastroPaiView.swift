//
//  CadastroView.swift
//  testerotakids
//
//  Created by Juan Carlos on 15/05/25.
//

import SwiftUI

struct CadastroPaiView: View {
    @StateObject var viewmodelcadastro = ViewModelCadastro()
    
    var body: some View {
        ZStack {
            Color.azulclaro
            
            VStack(alignment: .leading) {
                HStack {
                    Image("rotakidspng")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                    Spacer()
                }
                .padding(.horizontal)
                .background()
                
                
                ScrollView {
                    
                    
                    VStack(alignment: .leading) {
                        Text("Colégio:")
                            .bold()
                            .foregroundColor(.laranja)
                            .font(.system(size: 22))
                        TextField("  Colégio:", text: $viewmodelcadastro.colegio)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Horário")
                            .bold()
                            .foregroundColor(.laranja)
                            .font(.system(size: 22))
                        TextField("  Horário:", text: $viewmodelcadastro.horario)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        
                        Text("Criança:")
                            .bold()
                            .foregroundColor(.laranja)
                            .font(.system(size: 22))
                        TextField("  Apelido:", text: $viewmodelcadastro.apelido)
                            .background(RoundedRectangle(cornerRadius: 50).fill(.white).frame(height: 30))
                        
                        Text("Observações:")
                            .bold()
                            .foregroundColor(.laranja)
                            .font(.system(size: 22))
                        TextField("  Observações:", text: $viewmodelcadastro.observacoes, axis: .vertical)
                            .textFieldStyle(.roundedBorder)
                        
                        Spacer(minLength: 40)
                    }
                    .padding(.horizontal)
                    
                    HStack {
                        Spacer()
                        Button("Cadastrar") {
                            viewmodelcadastro.enviarDadosCadastro()
                        }
                        .foregroundColor(.white)
                        .bold()
                        .padding(.horizontal, 40)
                        .padding(.vertical, 15)
                        .background(RoundedRectangle(cornerRadius: 50).fill(.azul))
                        .padding(.trailing, 20)
                        .disabled(viewmodelcadastro.isLoading)
                        
                        if viewmodelcadastro.isLoading {
                            ProgressView()
                        }
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                }
            }
        }
        .alert(isPresented: $viewmodelcadastro.showAlert) {
            Alert(title: Text("Cadastro"), message: Text(viewmodelcadastro.alertMessage), dismissButton: .default(Text("OK")))
        }
    }
}

#Preview {
    CadastroPaiView()
}

