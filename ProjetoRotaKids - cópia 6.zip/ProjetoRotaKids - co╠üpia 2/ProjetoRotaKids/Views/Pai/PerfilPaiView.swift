//
//  ConfigPaiView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI

struct PerfilPaiView: View {
    @StateObject var vmpai = ViewModelPai()
    
    var body: some View {
        ZStack{
            Color(.azulclaro)
                .ignoresSafeArea()
            VStack{
                ForEach(vmpai.pais, id: \.self){ index in
                    AsyncImage(url: URL(string: index.foto)) { image in
                        image
                            .image?.resizable()
                            .scaledToFill()
                            .scaledToFit()
                            .cornerRadius(10)
                            .frame(width: 250, height: 250)
                    }
                    
                    
                    HStack{
                        Text("Nome: \(index.nome)")
                            .font(.system(size: 20))
                            .bold()
                    }
                    HStack{
                        Text("Telefone: \(index.telefone)")
                            .font(.system(size: 20))
                            .bold()
                    }
                    Spacer()
                }
            }.padding()
        }
        .onAppear(){
            vmpai.fetch()
        }
    }
}

#Preview {
    PerfilPaiView()
}
