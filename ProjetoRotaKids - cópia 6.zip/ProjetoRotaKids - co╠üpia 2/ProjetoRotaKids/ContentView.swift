//
//  ContentView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 13/05/25.
//

import SwiftUI

struct ContentView: View {
    @State var crianca: Crianca
    @State var motorista: Motorista
    
    var body: some View {
        NavigationStack{
            ZStack{
                Color.azulclaro
                    .ignoresSafeArea()
                VStack{
                    Image("rotakidspng")
                        .resizable()
                        .scaledToFit()
                    NavigationLink(destination: MenuMotoristaView()){
                        ZStack{
                            Rectangle()
                                .foregroundColor(.azul)
                                .frame(width: 250, height: 100)
                                .cornerRadius(20)
                            Text("MOTORISTA")
                                .font(.title)
                                .bold()
                                .foregroundColor(.laranja)
                        }
                    }
                        NavigationLink (destination: MenuPaiView(motorista: motorista, crianca: crianca)) {
                            ZStack{
                            Rectangle()
                                .foregroundColor(.azul)
                                .frame(width: 250, height: 100)
                                .cornerRadius(20)

                            Text("PAI")
                                .font(.title)
                                .bold()
                                .foregroundColor(.laranja)
                        }
                    }
                    Spacer()
                }
            }
        }
    }
}
#Preview {
    ContentView(crianca: Crianca(idPai: "1234", idMotora: "1357", apelido: "Junin", foto: "https://i.pinimg.com/736x/83/a7/dd/83a7dd29130f6641cb299d94729024ae.jpg", colegio: "Catolica", horario: "12:30h", colLat: 0.0, colLon: 0.0, observacoes: "Gosta de morder!"), motorista: Motorista(idMotora: "1357", nome: "", cnh: "", foto: "", telefone: "", veiculos: Veiculo(idVan: "", placa: "", modelo: "", foto: "", cor: "", latitude: 0.0, longitude: 0.0)))
}
