//
//  PaiView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 13/05/25.
//

import SwiftUI

struct PaiView: View {
    
    @StateObject var viewmodelpai = ViewModelPai()
    @StateObject var vmkid = ViewModelCrianca()
    
    @State var motorista: Motorista
    @State var crianca: Crianca
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.azulclaro
                    .ignoresSafeArea()
                VStack{
                    ForEach(viewmodelpai.pais, id: \.self){ index in
                        VStack{
                            HStack {
                                AsyncImage(url: URL(string: "\(index.foto)"),
                                           content: {
                                    image in
                                    
                                    image.resizable()
                                }, placeholder: {
                                    ProgressView()
                                })
                                .frame(width: 100, height: 100)
                                .cornerRadius(50)
                            }
                            Text(index.nome)
                                .bold()
                                .font(.system(size: 20))
                        }
                        
                        
                        Text("Crianças cadastradas")
                            .font(.system(size: 20))
                    }
                    Divider()
                    
                    ScrollView(.vertical){
                        ForEach(vmkid.criancas, id: \.self){ kids in
                            if kids.idPai == "1234"{
                                NavigationLink(destination: MenuKidsView(motorista: motorista, kid: kids)){
                                    HStack{
                                        AsyncImage(url: URL(string: kids.foto)) {image in
                                            image.image?.resizable()
                                                .frame(width: 80, height: 80)
                                                .cornerRadius(50)
                                                .padding(10)
                                        }
                                        Text(kids.apelido)
                                            .font(.title)
                                            .foregroundColor(.black)
                                        Spacer()
                                    }
                                }
                                
                            }
                        }
                    }
                    Divider()
                    
                    NavigationLink(destination: CadastroPaiView()){
                        ZStack{
                            Rectangle()
                                .frame(width: 200, height: 50)
                                .cornerRadius(40)
                            Text("CADASTRAR CRIANÇA")
                                .foregroundColor(.white)
                                .font(.system(size: 15))
                                .bold()
                        }
                    }
                    Spacer()
                }.padding()
            }
        }
        .onAppear(){
            vmkid.fetch()
            viewmodelpai.fetch()
        }
    }
    
    

}

#Preview {
    PaiView(motorista: Motorista(idMotora: "1357", nome: "", cnh: "", foto: "", telefone: "", veiculos: Veiculo(idVan: "", placa: "", modelo: "", foto: "", cor: "", latitude: 0.0, longitude: 0.0)), crianca: Crianca(idPai: "1234", idMotora: "1357", apelido: "Junin", foto: "https://i.pinimg.com/736x/83/a7/dd/83a7dd29130f6641cb299d94729024ae.jpg", colegio: "Catolica", horario: "12:30h", colLat: 0.0, colLon: 0.0, observacoes: "Gosta de morder!"))
}
