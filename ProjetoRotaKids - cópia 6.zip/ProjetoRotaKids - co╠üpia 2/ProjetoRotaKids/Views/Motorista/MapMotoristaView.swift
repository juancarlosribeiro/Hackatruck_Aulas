import SwiftUI
import MapKit

struct MapMotoristaView: View {
    @StateObject var vm = ViewModelMotorista()
    @StateObject var vmKid = ViewModelCrianca()
    
    @State var position = MapCameraPosition.region(
    MKCoordinateRegion(
    center: CLLocationCoordinate2D(latitude: -15.7938, longitude: -47.8827),
    span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.01))
    )
    
    var body: some View {
        VStack{
            Map(position: $position) {
                
                Annotation("Escola", coordinate: CLLocationCoordinate2D(latitude: -15.8624934, longitude: -48.0332559)) {
                    AsyncImage(url: URL(string: "https://www.freeiconspng.com/thumbs/school-icon-png/high-school-icon-png-8.png")) {
                        image in
                        
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(width: 50, height: 50)
                    .clipShape(Circle())
                }
                
                ForEach(vm.motora, id: \.self){
                    index in
                    
                    Annotation("\(index.veiculos.modelo)", coordinate: CLLocationCoordinate2D(latitude: index.veiculos.latitude, longitude: index.veiculos.longitude)) {
                        AsyncImage(url: URL(string: "\(index.veiculos.foto)")){
                            image in
                            image.resizable()
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(width: 50, height: 50)
                        .clipShape(Circle())
                    }
                }
                        
                ForEach(vmKid.criancas, id: \.self) {
                    c in
                    
                    Annotation(c.apelido, coordinate: CLLocationCoordinate2DMake(c.colLat, c.colLon), content: {
                        AsyncImage(url: URL(string: "\(c.foto)")){
                            image in
                            image.resizable()
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(width: 50, height: 50)
                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    })
                }
                        
                    
                
            }
            .ignoresSafeArea()
        }
        .onAppear(){
            vm.fetch()
            vmKid.fetch()
        }
    }
}

#Preview {
    MapMotoristaView()
}
