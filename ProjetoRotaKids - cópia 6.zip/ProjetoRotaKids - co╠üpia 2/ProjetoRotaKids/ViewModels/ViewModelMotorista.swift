//
//  ViewModelMotorista.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 13/05/25.
//

import Foundation

class ViewModelMotorista: ObservableObject {
    
    @Published var motora: [Motorista] = []
    
    func fetch(){
        guard let url = URL(string: "http://192.168.128.89:1880/GetMotorista") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Motorista].self, from: data)
                DispatchQueue.main.async {
                    self?.motora = parsed
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
    func kidStatus(idMoto: String, idPai: String, nome: String, status: Bool){
        var message = Notificacao(motoId: idMoto, paraPai: idPai, nomeCrianca: nome, status: true, hora: Date.now)
        
        let url = URL(string: "http://192.168.128.89:1880/statuscrianca")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if !status {
            message = Notificacao(motoId: idMoto, paraPai: idPai, nomeCrianca: nome, status: false, hora: Date.now)
        }
        
        let data = try! JSONEncoder().encode(message)
        request.httpBody = data
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            let statusCode = (response as! HTTPURLResponse).statusCode

            if statusCode == 200 {
                print("SUCCESS")
            } else {
                print("FAILURE")
            }
        }
        
        task.resume()
        
    }

}
