//
//  MenuMotoristaView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 15/05/25.
//

import SwiftUI

struct MenuMotoristaView: View {
    var body: some View {
        TabView {
            ListaCriancasView()
                .tabItem {
                    Label("CRIANCAS", systemImage: "person.3.fill")
                }
            MapMotoristaView()
                .tabItem {
                    Label("MAPA", systemImage: "map.fill")
                }
            MotoristaView()
                .tabItem {
                    Label("PERFIL", systemImage: "person.fill")
                }
            
        }
    }
}

#Preview {
    MenuMotoristaView()
}
