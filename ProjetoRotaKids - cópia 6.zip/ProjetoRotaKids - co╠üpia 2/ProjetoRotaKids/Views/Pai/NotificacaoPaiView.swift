//
//  TelaNotificacoes.swift
//  TelaCadastro
//
//  Created by Turma01-17 on 15/05/25.
//

import SwiftUI

struct NotificacaoPaiView: View {
    @StateObject var vm = ViewModelKid()
    
    var body: some View {
        ZStack{
            Color.azulclaro
                .ignoresSafeArea()
            
            VStack{
                VStack(alignment: .leading){
                    HStack{
                        Image("rotakidspng")
                            .resizable()
                            .scaledToFit()
                            .scaledToFill()
                            .frame(width: 80,height: 80)
                        
                        Spacer()
                        
                    }.padding(.horizontal)
                        .background()
                    
                }
                
                Text("Notificações")
                    .bold()
                    .font(.system(size: 28))
                Divider()
                    .background(Color.black)
                
                        ScrollView{
                            ForEach(vm.notificacoes, id: \.self){
                                n in
                                
                                if n.paraPai == "1234" && n.status == false {
                                    VStack{
                                        VStack(alignment: .leading){
                                            HStack{
                                                Text("Aviso de notificação")
                                                    .bold()
                                                Spacer()
                                                Text("\(n.hora.formatted())")
                                            }
                                            HStack{
                                                Text("\(n.nomeCrianca) desembarcou.")
                                            }
                                        }
                                    }
                                    .padding()
                                }
                                
                                if n.paraPai == "1234" && n.status == true {
                                    VStack{
                                        VStack(alignment: .leading){
                                            HStack{
                                                Text("Aviso de notificação")
                                                    .bold()
                                                Spacer()
                                                Text("\(n.hora.formatted())")
                                            }
                                            HStack{
                                                Text("\(n.nomeCrianca) embarcou.")
                                            }
                                        }
                                    }
                                    .padding()
                                }
                            }
    
                }
                Spacer()
            }
        }
        .onAppear(){
            vm.fetch()
        }
    }
}

#Preview {
    NotificacaoPaiView()
}

