//
//  MenuPaiView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI

struct MenuPaiView: View {
    @State var motorista: Motorista
    @State var crianca: Crianca
    
    var body: some View {
        TabView {
            PaiView(motorista: motorista, crianca: crianca)
                .tabItem {
                    Label("PERFIL", systemImage: "person.circle.fill")
                }
            
            NotificacaoPaiView()
                .tabItem {
                    Label("NOTIFICAÇÕES", systemImage: "bell.badge.fill")
                }
            
            PerfilPaiView()
                .tabItem {
                    Label("PERFIL", systemImage: "person.fill")
                }
        }
    }
}

#Preview {
    MenuPaiView(motorista: Motorista(idMotora: "1357", nome: "", cnh: "", foto: "", telefone: "", veiculos: Veiculo(idVan: "", placa: "", modelo: "", foto: "", cor: "", latitude: 0.0, longitude: 0.0)), crianca: Crianca(idPai: "1234", idMotora: "1357", apelido: "Junin", foto: "https://i.pinimg.com/736x/83/a7/dd/83a7dd29130f6641cb299d94729024ae.jpg", colegio: "Catolica", horario: "12:30h", colLat: 0.0, colLon: 0.0, observacoes: "Gosta de morder!"))
}
