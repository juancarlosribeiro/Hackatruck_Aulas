//
//  VanView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI

struct VanView: View {
    @StateObject var van = ViewModelMotorista()
    
    var body: some View {
        ZStack{
            Color(.azulclaro)
                .ignoresSafeArea()
            VStack{
            Text("Informações da van:")
                .padding(.top)
                .font(.title)
                .bold()
                ForEach(van.motora, id: \.self){ index in
                    AsyncImage(url: URL(string: index.veiculos.foto)) { image in
                        image
                            .image?.resizable()
                            .frame(width: 250, height: 250)
                    }
                    
                    HStack{
                        Text("Modelo: \(index.veiculos.modelo)")
                            .font(.callout)
                            .bold()
                    }
                    HStack{
                        Text("Placa: \(index.veiculos.placa)")
                            .font(.callout)
                            .bold()
                    }
                    HStack{
                        Text("Cor: \(index.veiculos.cor)")
                            .font(.callout)
                            .bold()
                    }
                    Spacer()
                }
            }
        }
                    .onAppear(){
            van.fetch()
                        }
            }
        }

#Preview {
    VanView()
}
