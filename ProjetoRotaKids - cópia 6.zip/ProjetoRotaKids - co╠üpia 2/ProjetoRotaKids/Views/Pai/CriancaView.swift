//
//  CriancaView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI

struct CriancaView: View {
    @State var kid: Crianca
    
    var body: some View {
        ZStack{
            Color.azulclaro
                .ignoresSafeArea()
                    VStack{
                        AsyncImage(url: URL(string: kid.foto)){ image in
                            image
                                .image?.resizable()
                                .frame(width:300, height: 300)
                        }
                        Text("Nome: \(kid.apelido)")
                            .font(.title)
                            .multilineTextAlignment(.center)
                        Text("Colégio: \(kid.colegio)")
                            .font(.title)
                            .multilineTextAlignment(.center)
                        Text("Horário: \(kid.horario)")
                            .font(.title)
                            .multilineTextAlignment(.center)
                        Text("Observações:\n\(kid.observacoes)")
                            .font(.title)
                            .multilineTextAlignment(.center)
                    }
        }
    }
}

#Preview {
    CriancaView(kid: Crianca(idPai: "1234", idMotora: "1357", apelido: "Junin", foto: "https://i.pinimg.com/736x/83/a7/dd/83a7dd29130f6641cb299d94729024ae.jpg", colegio: "Catolica", horario: "12:30h", colLat: 0.0, colLon: 0.0, observacoes: "Gosta de morder!"))
}

