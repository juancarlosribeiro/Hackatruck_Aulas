//
//  ViewModelCrianca.swift
//  ProjetoRotaKids
//
//  Created by Turma02-2 on 20/05/25.
//

import Foundation

class ViewModelCrianca: ObservableObject {
    
    @Published var criancas: [Crianca] = []
    
    func fetch(){
        guard let url = URL(string: "http://192.168.128.89:1880/GetKids") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Crianca].self, from: data)
                
                DispatchQueue.main.async {
                    self?.criancas = parsed
                }
                
            } catch {
                print(error)
            }
        }
        
        task.resume()
    }
    
}
