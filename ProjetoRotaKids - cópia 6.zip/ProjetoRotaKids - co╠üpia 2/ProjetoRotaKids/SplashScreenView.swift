//
//  SplashScreenView.swift
//  ProjetoRotaKids
//
//  Created by Igor Teles Lima  on 22/05/25.
//

import SwiftUI

struct SplashScreenView: View {
    var body: some View {
        ZStack {
            Color.azulclaro
                .ignoresSafeArea()
            Image("rotakidspng")
                .resizable()
                .scaledToFit()
                .frame(width: 250, height: 250)
                .shadow(radius: 10)
        }
    }
}

struct SplashScreenView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView()
    }
}
