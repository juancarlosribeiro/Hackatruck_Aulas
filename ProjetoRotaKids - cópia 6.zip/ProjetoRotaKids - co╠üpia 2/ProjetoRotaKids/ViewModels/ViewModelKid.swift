//
//  ViewModelKid.swift
//  RotaKids
//
//  Created by Turma02-2 on 20/05/25.
//

import Foundation


class ViewModelKid: ObservableObject {
    
    @Published var notificacoes: [Notificacao] = []
    
    func fetch(){
        guard let url = URL(string: "http://192.168.128.89:1880/Getstatuscrianca") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Notificacao].self, from: data)
                
                DispatchQueue.main.async {
                    self?.notificacoes = parsed
                }
            } catch {
                print(error)
            }
        }
        
        task.resume()
    }
    
}
