//
//  Model.swift
//  testerotakids
//
//  Created by Igor Teles Lima  on 15/05/25.
//

import Foundation

struct Motorista: Codable, Hashable {
    let idMotora: String
    let nome: String
    let cnh: String
    let foto: String
    let telefone: String
    let veiculos: Veiculo //edilson
}

struct Veiculo: Codable, Hashable {
    let idVan: String
    let placa: String
    let modelo: String
    let foto: String
    let cor: String
    let latitude: Double
    let longitude: Double
    //let criancas: [Crianca]
}

struct Pai: Codable, Hashable {
    let idPai: String
    let nome: String
    let foto: String
    let telefone: String
    let enderecoLat: Double
    let enderecoLong: Double
    //let criancas: [Crianca]
}

struct Crianca: Codable, Hashable {
    let idPai: String
    let idMotora: String
    let apelido: String
    let foto: String
    let colegio: String
    let horario: String
    let colLat: Double
    let colLon: Double
    let observacoes: String
}

struct Localizacao: Codable, Hashable {
    let latitude: Double
    let longitude: Double
    let altitude: Double
    let timestamp: Date
}


struct Notificacao: Codable, Hashable {
    let motoId: String
    let paraPai: String
    let nomeCrianca: String
    let status: Bool
    let hora: Date
}

/*
 
 [
 motorista exemplo
 {
      "idMotora": "1357",
      "nome": "Maurilho dis Anjos",
      "cnh": "1234abcd",
      "foto": "https://static.wikia.nocookie.net/tv-quase/images/a/a8/Maurilio-dos-anjos-look.jpg/revision/latest?cb=20190914142716&path-prefix=pt-br",
      "telefone": "61 912345678",
      "van": {
           "idVan": "2468",
           "placa": "jpg-1234",
           "modelo": "Kombi",
           "foto": "https://cdn.grupolance.com.br/batches/8c/18852/6c3372adcafad6a32fcf4d144e51b458.jpg",
           "cor": "Branca",
           "latitude": -15.7938,
           "longitude": -47.8827
       }
 }
 
 
 pai exemplo
 {
     "idPai": "1234",
     "nome": "Julinho da Van",
     "foto": "https://static.wikia.nocookie.net/tv-quase/images/4/4a/Julinho-da-van-look.jpg/revision/latest?cb=20190914145407&path-prefix=pt-br",
     "telefone": "6361241241",
     "enderecoLat": -15.813743,
     "enderecoLong": -47.886892
 }
 
 ciranca exemplo
 
 [
 {
     "idPai": "1234",
     "idMotora": "1357",
     "apelido": "Renanzinho",
     "foto": "https://img.freepik.com/vetores-premium/menino-alegre-pulando-crianca-feliz-animada-personagem-de-desenho-animado-bonito-isolada-no-fundo-branco_533410-357.jpg",
     "colegio": "La Salle",
     "horario": "12:30h",
     "colLat": -15.802843,
     "colLon": -47.900602,
     "observacoes": "gosta de morder"
 },
  {
      "idPai": "1234",
      "idMotora": "1357",
      "apelido": "Jorgin",
      "foto": "https://i.pinimg.com/736x/83/a7/dd/83a7dd29130f6641cb299d94729024ae.jpg",
      "colegio": "La Salle",
      "horario": "12:30h",
      "colLat": -15.808431,
      "colLon": -47.882166,
      "observacoes": "gosta de bater"
  },
  {
     "idPai": "9999",
     "idMotora": "1357",
     "apelido": "Carlos",
     "foto": "https://artpoin.com/wp-content/uploads/2023/10/dia-das-criancas-desenho4-1448x2048.png",
     "colegio": "La Salle",
     "horario": "12:30h",
     "colLat": -15.811085,
     "colLon": -47.895925,
     "observacoes": "gosta de morder"
 },
  {
      "idPai": "9999",
      "idMotora": "1357"
      "apelido": "Daniela",
      "foto": "https://i.pinimg.com/736x/e5/80/22/e5802233848cd7079f99f3a537c33194.jpg",
      "colegio": "La Salle",
      "horario": "12:30h",
      "colLat": -15.811791,
      "colLon": -47.884767,
      "observacoes": "gosta de bater"
 }
 ]
 
 
 
 
 {
      "idMotora": "5678"
      "nome": "Maurilho dis Anjos",
      "cnh": "1234abcd",
      "foto": "https://static.wikia.nocookie.net/tv-quase/images/a/a8/Maurilio-dos-anjos-look.jpg/revision/latest?cb=20190914142716&path-prefix=pt-br",
      "telefone": "61 912345678",
      "van": {
           "placa": "jpg-1234",
           "modelo": "Kombi",
           "foto": "https://cdn.grupolance.com.br/batches/8c/18852/6c3372adcafad6a32fcf4d144e51b458.jpg",
           "cor": "Branca",
           "latitude": -15.7938,
           "longitude": -47.8827,
          "criancas": [{
              "idPai": "1234",
              "apelido": "Renanzinho",
              "foto": "https://img.freepik.com/vetores-premium/menino-alegre-pulando-crianca-feliz-animada-personagem-de-desenho-animado-bonito-isolada-no-fundo-branco_533410-357.jpg",
              "colegio": "La Salle",
              "horario": "12:30h",
              "colLat": -15.802843,
              "colLon": -47.900602,
              "observacoes": "gosta de morder"
          },
           {
               "idPai": "1234",
               "apelido": "Jorgin",
               "foto": "https://i.pinimg.com/736x/83/a7/dd/83a7dd29130f6641cb299d94729024ae.jpg",
               "colegio": "La Salle",
               "horario": "12:30h",
               "colLat": -15.808431,
               "colLon": -47.882166,
               "observacoes": "gosta de bater"
           },
           {
              "idPai": "9999",
              "apelido": "Carlos",
              "foto": "https://artpoin.com/wp-content/uploads/2023/10/dia-das-criancas-desenho4-1448x2048.png",
              "colegio": "La Salle",
              "horario": "12:30h",
              "colLat": -15.811085,
              "colLon": -47.895925,
              "observacoes": "gosta de morder"
          },
           {
               "idPai": "9999",
               "apelido": "Daniela",
               "foto": "https://i.pinimg.com/736x/e5/80/22/e5802233848cd7079f99f3a537c33194.jpg",
               "colegio": "La Salle",
               "horario": "12:30h",
               "colLat": -15.811791,
               "colLon": -47.884767,
               "observacoes": "gosta de bater"
          }
          ]
      }
 }
 
  ]
 
 */

/*
{
    "idPai": "1234",
    "nome": "Julinho da Van",
    "foto": "https://static.wikia.nocookie.net/tv-quase/images/4/4a/Julinho-da-van-look.jpg/revision/latest?cb=20190914145407&path-prefix=pt-br",
    "telefone": "6361241241",
    "enderecoLat": "propria van",
    "enderecoLong": "propria van",
    "criancas": [{
         "idPai": "1234",
         "apelido": "Renanzinho",
         "foto": "https://img.freepik.com/vetores-premium/menino-alegre-pulando-crianca-feliz-animada-personagem-de-desenho-animado-bonito-isolada-no-fundo-branco_533410-357.jpg",
         "colegio": "La Salle",
         "horario": "12:30h",
         "colLat": -15.802843,
         "colLon": -47.900602,
         "observacoes": "gosta de morder"
        },
        {
          "idPai": "1234",
          "apelido": "Jorgin",
          "foto": "https://i.pinimg.com/736x/83/a7/dd/83a7dd29130f6641cb299d94729024ae.jpg",
          "colegio": "La Salle",
          "horario": "12:30h",
          "colLat": -15.808431,
          "colLon": -47.882166,
          "observacoes": "gosta de bater"
        }]
}
 
 
 
 [
     {
         "id": "270c4e86baa8cd63",
         "type": "tab",
         "label": "Alessandro Sampaio",
         "disabled": false,
         "info": "",
         "env": []
     },
     {
         "id": "6cc37c59fbb0a9e0",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 530,
         "y": 460,
         "wires": []
     },
     {
         "id": "0a131cc702ce10db",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/rotakidsmotorista",
         "method": "get",
         "upload": false,
         "swaggerDoc": "",
         "x": 130,
         "y": 460,
         "wires": [
             [
                 "c5b0f3a461a14144"
             ]
         ]
     },
     {
         "id": "102ada27e5f2c47d",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/rotakidsmotorista",
         "method": "post",
         "upload": false,
         "swaggerDoc": "",
         "x": 140,
         "y": 380,
         "wires": [
             [
                 "b970164a2e76617d"
             ]
         ]
     },
     {
         "id": "1b44b04d9c0d03ba",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 710,
         "y": 380,
         "wires": []
     },
     {
         "id": "b40c092219d6281c",
         "type": "cloudantplus out",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakidsmotorista",
         "service": "_ext_",
         "payonly": true,
         "operation": "insert",
         "x": 530,
         "y": 380,
         "wires": [
             [
                 "1b44b04d9c0d03ba"
             ]
         ]
     },
     {
         "id": "c5b0f3a461a14144",
         "type": "cloudantplus in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakidsmotorista",
         "service": "_ext_",
         "search": "_all_",
         "design": "",
         "index": "",
         "x": 350,
         "y": 460,
         "wires": [
             [
                 "6cc37c59fbb0a9e0"
             ]
         ]
     },
     {
         "id": "14b0dcb261aae4f8",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/atualizar",
         "method": "patch",
         "upload": false,
         "swaggerDoc": "",
         "x": 110,
         "y": 140,
         "wires": [
             [
                 "2c65d608e06890b2"
             ]
         ]
     },
     {
         "id": "13021bb2cac41741",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 510,
         "y": 140,
         "wires": []
     },
     {
         "id": "0fb9233c33b2e664",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "/v1/rotakidsmotorista",
         "method": "delete",
         "upload": false,
         "swaggerDoc": "",
         "x": 140,
         "y": 520,
         "wires": [
             [
                 "84ea787b2cbb5106"
             ]
         ]
     },
     {
         "id": "ca3f2b7716f03faa",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 550,
         "y": 520,
         "wires": []
     },
     {
         "id": "2c65d608e06890b2",
         "type": "cloudantplus out",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakids",
         "service": "_ext_",
         "payonly": true,
         "operation": "insert",
         "x": 280,
         "y": 140,
         "wires": [
             [
                 "13021bb2cac41741"
             ]
         ]
     },
     {
         "id": "84ea787b2cbb5106",
         "type": "cloudantplus out",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakidsmotorista",
         "service": "_ext_",
         "payonly": true,
         "operation": "delete",
         "x": 370,
         "y": 520,
         "wires": [
             [
                 "ca3f2b7716f03faa"
             ]
         ]
     },
     {
         "id": "d9d0d58d44d314f8",
         "type": "split",
         "z": "270c4e86baa8cd63",
         "name": "",
         "splt": "",
         "spltType": "str",
         "arraySplt": 1,
         "arraySpltType": "len",
         "stream": false,
         "addname": "",
         "x": 350,
         "y": 360,
         "wires": [
             [
                 "b40c092219d6281c"
             ]
         ]
     },
     {
         "id": "b970164a2e76617d",
         "type": "switch",
         "z": "270c4e86baa8cd63",
         "name": "",
         "property": "payload",
         "propertyType": "msg",
         "rules": [
             {
                 "t": "istype",
                 "v": "array",
                 "vt": "array"
             },
             {
                 "t": "istype",
                 "v": "object",
                 "vt": "object"
             }
         ],
         "checkall": "true",
         "repair": false,
         "outputs": 2,
         "x": 350,
         "y": 400,
         "wires": [
             [
                 "d9d0d58d44d314f8"
             ],
             [
                 "b40c092219d6281c"
             ]
         ]
     },
     {
         "id": "8dc577150ac378cc",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/rotakidspai",
         "method": "post",
         "upload": false,
         "swaggerDoc": "",
         "x": 120,
         "y": 680,
         "wires": [
             [
                 "c28a111113ef8ae4"
             ]
         ]
     },
     {
         "id": "3b8ff23b2f3577ca",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 710,
         "y": 680,
         "wires": []
     },
     {
         "id": "06af10b214a9b5e5",
         "type": "cloudantplus out",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakidspai",
         "service": "_ext_",
         "payonly": true,
         "operation": "insert",
         "x": 530,
         "y": 680,
         "wires": [
             [
                 "3b8ff23b2f3577ca"
             ]
         ]
     },
     {
         "id": "35ef7d46e73f0808",
         "type": "split",
         "z": "270c4e86baa8cd63",
         "name": "",
         "splt": "",
         "spltType": "str",
         "arraySplt": 1,
         "arraySpltType": "len",
         "stream": false,
         "addname": "",
         "x": 350,
         "y": 660,
         "wires": [
             [
                 "06af10b214a9b5e5"
             ]
         ]
     },
     {
         "id": "c28a111113ef8ae4",
         "type": "switch",
         "z": "270c4e86baa8cd63",
         "name": "",
         "property": "payload",
         "propertyType": "msg",
         "rules": [
             {
                 "t": "istype",
                 "v": "array",
                 "vt": "array"
             },
             {
                 "t": "istype",
                 "v": "object",
                 "vt": "object"
             }
         ],
         "checkall": "true",
         "repair": false,
         "outputs": 2,
         "x": 350,
         "y": 700,
         "wires": [
             [
                 "35ef7d46e73f0808"
             ],
             [
                 "06af10b214a9b5e5"
             ]
         ]
     },
     {
         "id": "4ee70622135d4b6f",
         "type": "function",
         "z": "270c4e86baa8cd63",
         "name": "function 2",
         "func": "msg.payload = {\n    distancia: msg.payload.distancia,\n    data: Date.now()\n    }\nreturn msg;",
         "outputs": 1,
         "noerr": 0,
         "initialize": "",
         "finalize": "",
         "libs": [],
         "x": 800,
         "y": 140,
         "wires": [
             []
         ]
     },
     {
         "id": "fdb9be1703e8a3ae",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 530,
         "y": 760,
         "wires": []
     },
     {
         "id": "4d63b3c97ef45102",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/rotakidspai",
         "method": "get",
         "upload": false,
         "swaggerDoc": "",
         "x": 110,
         "y": 760,
         "wires": [
             [
                 "2ce18dc35be5390b"
             ]
         ]
     },
     {
         "id": "2ce18dc35be5390b",
         "type": "cloudantplus in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakidspai",
         "service": "_ext_",
         "search": "_all_",
         "design": "",
         "index": "",
         "x": 350,
         "y": 760,
         "wires": [
             [
                 "fdb9be1703e8a3ae"
             ]
         ]
     },
     {
         "id": "4cde1260aaa97e79",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "/v1/rotakidspai",
         "method": "delete",
         "upload": false,
         "swaggerDoc": "",
         "x": 120,
         "y": 820,
         "wires": [
             [
                 "eda558178748d46c"
             ]
         ]
     },
     {
         "id": "537eff772b248b37",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 550,
         "y": 820,
         "wires": []
     },
     {
         "id": "eda558178748d46c",
         "type": "cloudantplus out",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakidspai",
         "service": "_ext_",
         "payonly": true,
         "operation": "delete",
         "x": 350,
         "y": 820,
         "wires": [
             [
                 "537eff772b248b37"
             ]
         ]
     },
     {
         "id": "a026a14b94b9951e",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/statuscrianca",
         "method": "post",
         "upload": false,
         "swaggerDoc": "",
         "x": 120,
         "y": 980,
         "wires": [
             [
                 "9e7b41b197bbda5f"
             ]
         ]
     },
     {
         "id": "c80df4c17056e2ab",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 710,
         "y": 980,
         "wires": []
     },
     {
         "id": "55769f8f27e211c7",
         "type": "cloudantplus out",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "statuscrianca",
         "service": "_ext_",
         "payonly": true,
         "operation": "insert",
         "x": 540,
         "y": 980,
         "wires": [
             [
                 "c80df4c17056e2ab"
             ]
         ]
     },
     {
         "id": "093788bef09f48b7",
         "type": "split",
         "z": "270c4e86baa8cd63",
         "name": "",
         "splt": "",
         "spltType": "str",
         "arraySplt": 1,
         "arraySpltType": "len",
         "stream": false,
         "addname": "",
         "x": 350,
         "y": 960,
         "wires": [
             [
                 "55769f8f27e211c7"
             ]
         ]
     },
     {
         "id": "9e7b41b197bbda5f",
         "type": "switch",
         "z": "270c4e86baa8cd63",
         "name": "",
         "property": "payload",
         "propertyType": "msg",
         "rules": [
             {
                 "t": "istype",
                 "v": "array",
                 "vt": "array"
             },
             {
                 "t": "istype",
                 "v": "object",
                 "vt": "object"
             }
         ],
         "checkall": "true",
         "repair": false,
         "outputs": 2,
         "x": 350,
         "y": 1000,
         "wires": [
             [
                 "093788bef09f48b7"
             ],
             [
                 "55769f8f27e211c7"
             ]
         ]
     },
     {
         "id": "5e5ed617d1963bd5",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 530,
         "y": 1060,
         "wires": []
     },
     {
         "id": "cbed123dbea8e0cc",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/statuscrianca",
         "method": "get",
         "upload": false,
         "swaggerDoc": "",
         "x": 120,
         "y": 1060,
         "wires": [
             [
                 "63c9e3c71399948c"
             ]
         ]
     },
     {
         "id": "63c9e3c71399948c",
         "type": "cloudantplus in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "statuscrianca",
         "service": "_ext_",
         "search": "_all_",
         "design": "",
         "index": "",
         "x": 360,
         "y": 1060,
         "wires": [
             [
                 "5e5ed617d1963bd5"
             ]
         ]
     },
     {
         "id": "aa8ab1335b9808a8",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/statuscrianca",
         "method": "delete",
         "upload": false,
         "swaggerDoc": "",
         "x": 130,
         "y": 1140,
         "wires": [
             [
                 "85783cb84472267d"
             ]
         ]
     },
     {
         "id": "89ebe197a7daaf83",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 550,
         "y": 1140,
         "wires": []
     },
     {
         "id": "85783cb84472267d",
         "type": "cloudantplus out",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "statuscrianca",
         "service": "_ext_",
         "payonly": true,
         "operation": "delete",
         "x": 380,
         "y": 1140,
         "wires": [
             [
                 "89ebe197a7daaf83"
             ]
         ]
     },
     {
         "id": "d53ab5c0d4ec599e",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/rotakidscrianca",
         "method": "post",
         "upload": false,
         "swaggerDoc": "",
         "x": 130,
         "y": 1280,
         "wires": [
             [
                 "57fc31842b05dc21"
             ]
         ]
     },
     {
         "id": "e69f135140e44637",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 710,
         "y": 1280,
         "wires": []
     },
     {
         "id": "6242a712de4a6238",
         "type": "cloudantplus out",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakidscrianca",
         "service": "_ext_",
         "payonly": true,
         "operation": "insert",
         "x": 540,
         "y": 1280,
         "wires": [
             [
                 "e69f135140e44637"
             ]
         ]
     },
     {
         "id": "e5c91eb3aeee8d43",
         "type": "split",
         "z": "270c4e86baa8cd63",
         "name": "",
         "splt": "",
         "spltType": "str",
         "arraySplt": 1,
         "arraySpltType": "len",
         "stream": false,
         "addname": "",
         "x": 350,
         "y": 1260,
         "wires": [
             [
                 "6242a712de4a6238"
             ]
         ]
     },
     {
         "id": "57fc31842b05dc21",
         "type": "switch",
         "z": "270c4e86baa8cd63",
         "name": "",
         "property": "payload",
         "propertyType": "msg",
         "rules": [
             {
                 "t": "istype",
                 "v": "array",
                 "vt": "array"
             },
             {
                 "t": "istype",
                 "v": "object",
                 "vt": "object"
             }
         ],
         "checkall": "true",
         "repair": false,
         "outputs": 2,
         "x": 350,
         "y": 1300,
         "wires": [
             [
                 "e5c91eb3aeee8d43"
             ],
             [
                 "6242a712de4a6238"
             ]
         ]
     },
     {
         "id": "57b1d8581942c99f",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 530,
         "y": 1360,
         "wires": []
     },
     {
         "id": "f0c7682bf123fdb4",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/rotakidscrianca",
         "method": "get",
         "upload": false,
         "swaggerDoc": "",
         "x": 130,
         "y": 1360,
         "wires": [
             [
                 "b052c8c8ac85edcc"
             ]
         ]
     },
     {
         "id": "b052c8c8ac85edcc",
         "type": "cloudantplus in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakidscrianca",
         "service": "_ext_",
         "search": "_all_",
         "design": "",
         "index": "",
         "x": 360,
         "y": 1360,
         "wires": [
             [
                 "57b1d8581942c99f"
             ]
         ]
     },
     {
         "id": "40d3fb7cac0a3ac2",
         "type": "http in",
         "z": "270c4e86baa8cd63",
         "name": "",
         "url": "v1/rotakidscrianca",
         "method": "delete",
         "upload": false,
         "swaggerDoc": "",
         "x": 130,
         "y": 1440,
         "wires": [
             [
                 "922915be098e4208"
             ]
         ]
     },
     {
         "id": "78e06ba639a86e95",
         "type": "http response",
         "z": "270c4e86baa8cd63",
         "name": "",
         "statusCode": "",
         "headers": {},
         "x": 550,
         "y": 1440,
         "wires": []
     },
     {
         "id": "922915be098e4208",
         "type": "cloudantplus out",
         "z": "270c4e86baa8cd63",
         "name": "",
         "cloudant": "79a50a99ed17808c",
         "database": "rotakidscrianca",
         "service": "_ext_",
         "payonly": true,
         "operation": "delete",
         "x": 380,
         "y": 1440,
         "wires": [
             [
                 "78e06ba639a86e95"
             ]
         ]
     },
     {
         "id": "79a50a99ed17808c",
         "type": "cloudantplus",
         "host": "https://f1c0dcf9-5075-4061-a1f8-2f4ca596058a-bluemix.cloudantnosqldb.appdomain.cloud",
         "name": "",
         "useapikey": true
     }
 ]
 
 
 */
