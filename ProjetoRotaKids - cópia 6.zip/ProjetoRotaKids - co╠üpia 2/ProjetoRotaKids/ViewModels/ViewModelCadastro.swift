//
//  ViewModelCadastro.swift
//  testerotakids
//
//  Created by Igor Teles Lima  on 15/05/25.
//

import Foundation
import SwiftUI

class ViewModelCadastro: ObservableObject {
    @Published var idPai: String = "1234"
    @Published var idMotora: String = "1357"
    @Published var apelido: String = ""
    @Published var foto: String = "https://i.pinimg.com/474x/a8/da/22/a8da222be70a71e7858bf752065d5cc3.jpg"
    @Published var colegio: String = ""
    @Published var horario: String = ""
    @Published var colLat = -15.8624934
    @Published var colLon = -48.0332559
    @Published var observacoes: String = ""
    
    @Published var showAlert: Bool = false
    @Published var alertMessage: String = ""
    @Published var isLoading: Bool = false
    @Published var isColegioValid = false
    @Published var isHorarioValid = false
    @Published var isApelidoValid = false
    
    var isFormValid: Bool {
        return isColegioValid && isHorarioValid && isApelidoValid
    }
    
    func validateColegio() {
        isColegioValid = !colegio.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    func validateHorario() {
        isHorarioValid = !horario.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    func validateApelido() {
        isApelidoValid = !apelido.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    func enviarDadosCadastro() {
        validateColegio()
        validateHorario()
        validateApelido()
        
        if !isFormValid {
            alertMessage = "Por favor, preencha todos os campos obrigatórios (Colégio, Horário, Apelido)."
            showAlert = true
            return
        }
        
        isLoading = true
        alertMessage = ""
        showAlert = false
        
        let dadosCadastro: [String: Any?] = [
            "idPai": idPai,
            "idMotora": idMotora,
            "apelido": apelido,
            "foto": foto,
            "colegio": colegio,
            "horario": horario,
            "colLat": colLat,
            "colLon": colLon,
            "observacoes": observacoes.isEmpty ? nil : observacoes
        ]
        
        guard let url = URL(string: "http://192.168.128.89:1880/Kids") else {
            print("URL inválida para cadastro.")
            alertMessage = "Erro: URL de cadastro inválida."
            showAlert = true
            isLoading = false
            return
        }
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: dadosCadastro, options: [])
            
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = jsonData
            
            URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
                DispatchQueue.main.async {
                    self?.isLoading = false
                    if let error = error {
                        print("Erro ao enviar dados de cadastro: \(error)")
                        self?.alertMessage = "Erro ao enviar os dados: \(error.localizedDescription)"
                        self?.showAlert = true
                        return
                    }
                    
                    guard let httpResponse = response as? HTTPURLResponse else {
                        self?.alertMessage = "Erro ao obter resposta do servidor."
                        self?.showAlert = true
                        return
                    }
                    
                    print("Resposta do servidor: \(httpResponse.statusCode)")
                    if (200...299).contains(httpResponse.statusCode) {
                        self?.alertMessage = "Cadastro realizado com sucesso!"
                        self?.showAlert = true
                        self?.colegio = ""
                        self?.horario = ""
                        self?.apelido = ""
                        self?.observacoes = ""
                        
                        self?.isColegioValid = false
                        self?.isHorarioValid = false
                        self?.isApelidoValid = false
                        
                    } else {
                        if let data = data, let responseString = String(data: data, encoding: .utf8) {
                            self?.alertMessage = "Erro no cadastro: \(httpResponse.statusCode) - \(responseString)"
                        } else {
                            self?.alertMessage = "Erro no cadastro: Status \(httpResponse.statusCode)"
                        }
                        self?.showAlert = true
                    }
                }
            }.resume()
            
        } catch {
            DispatchQueue.main.async {
                self.isLoading = false
                print("Erro ao serializar dados para JSON: \(error)")
                self.alertMessage = "Erro interno ao processar os dados."
                self.showAlert = true
            }
        }
    }
}
