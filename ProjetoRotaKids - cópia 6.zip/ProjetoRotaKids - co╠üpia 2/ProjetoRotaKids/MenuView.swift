//
//  MenuView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI

struct MenuView: View {
    var body: some View {
        TabView {
            PaiView()
                .tabItem {
                    Label("PERFIL", systemImage: "person.circle.fill")
                }
           
            VanView()
                .tabItem {
                    Label("VAN", systemImage: "bus.fill")
                }
            
            MapaView()
                .tabItem {
                    Label("MAPA", systemImage: "map.fill")
                }
            
            NotfView()
                .tabItem {
                    Label("NOTIFICAÇÕES", systemImage: "bell.badge.fill")
                }
        }
    }
}

#Preview {
    MenuView()
}
