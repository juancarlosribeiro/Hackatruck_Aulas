//
//  MapaView.swift
//  ProjetoRotaKids
//
//  Created by Turma01-3 on 14/05/25.
//

import SwiftUI
import MapKit

struct MapaPaiView: View {
    @StateObject var viewModelPai = ViewModelPai()
    //@StateObject var vmMotorista = ViewModelMotorista()
    
    @State private var position: MapCameraPosition = .region(MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: -15.8638, longitude: -48.0327),
        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
    ))
    
    
    @State  var latAux: Double = 0
    @State  var longAux: Double = 0
    var body: some View {
        VStack {
            Text("Localização da Van do Motorista")
                .font(.title2)
                .bold()
                .padding()
            
            Map(position: $position) {
                ForEach(viewModelPai.locais, id: \.self){
                    loc in
                    
                    Annotation("Van", coordinate: CLLocationCoordinate2D(latitude: loc.latitude, longitude: loc.longitude)) {
                        VStack {
                            Image(systemName: "car.fill")
                                .font(.title)
                                .foregroundColor(.blue)
                        }
                        .padding(5)
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(8)
                        .shadow(radius: 3)
                        
                        .onTapGesture {
                            
                            latAux = loc.latitude
                            longAux = loc.longitude
                        }
                    }
                }
            }
        }
        .onAppear {
            viewModelPai.obterLocalizacaoDoMotorista()

            Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { _ in
                viewModelPai.obterLocalizacaoDoMotorista()
            }
        }
        .onChange(of: viewModelPai.locais) { _, newLocais in
            if let loc = newLocais.first {
                position = MapCameraPosition.region(MKCoordinateRegion(
                    center: CLLocationCoordinate2D(latitude: loc.latitude, longitude: loc.longitude),
                    span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)))
            }
        }
    }
}
#Preview {
    MapaPaiView()
}
